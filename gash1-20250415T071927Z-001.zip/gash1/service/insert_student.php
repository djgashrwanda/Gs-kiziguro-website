<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kiziguro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed: ' . $conn->connect_error
    ]);
    exit();
}

// Check if the request is a POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from the POST request
    $student_name = $_POST['s_name'] ?? '';
    $family_name = $_POST['s_fname'] ?? '';
    $student_gender = $_POST['s_gender'] ?? '';
    $family_id = $_POST['fh_id'] ?? '';
    $family_phone = $_POST['fh_number'] ?? '';
    $student_level = $_POST['s_level'] ?? '';

    // Validate required fields
    if (empty($student_name) || empty($family_name) || empty($student_gender) || empty($family_id) || empty($family_phone) || empty($student_level)) {
        echo json_encode([
            'success' => false,
            'message' => 'All fields are required!'
        ]);
        exit();
    }

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO student_registration (student_name, family_name, student_gender, family_id, family_phone, student_level) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $student_name, $family_name, $student_gender, $family_id, $family_phone, $student_level);

    // Execute and return response
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Student registered successfully!'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error inserting data: ' . $stmt->error
        ]);
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}
?>
