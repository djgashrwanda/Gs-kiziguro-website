<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'kiziguro');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
