<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kiziguro";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Handle POST update request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $student_name = $_POST['student_name'];
    $family_name = $_POST['family_name'];
    $student_gender = $_POST['student_gender'];
    $family_id = $_POST['family_id'];
    $family_phone = $_POST['family_phone'];
    $student_level = $_POST['student_level'];

    $stmt = $conn->prepare("UPDATE student_registration SET student_name = ?, family_name = ?, student_gender = ?, family_id = ?, family_phone = ?, student_level = ? WHERE id = ?");
    $stmt->bind_param("ssssssi", $student_name, $family_name, $student_gender, $family_id, $family_phone, $student_level, $id);

    if ($stmt->execute()) {
        echo "<script>alert('Record updated successfully.'); window.location.href = 'report.php';</script>";
    } else {
        echo "<script>alert('Failed to update record: " . $stmt->error . "'); window.location.href = 'report.php';</script>";
    }

    $stmt->close();
}

$conn->close();
?>
