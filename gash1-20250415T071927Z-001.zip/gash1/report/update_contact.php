<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kiziguro";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Handle POST update request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $contact_name = $_POST['contact_name'];
    $contact_number = $_POST['contact_number'];
    $contact_description = $_POST['contact_description'];

    $stmt = $conn->prepare("UPDATE contact_us SET contact_name = ?, contact_number = ?, contact_description = ? WHERE id = ?");
    $stmt->bind_param("sssi", $contact_name, $contact_number, $contact_description, $id);

    if ($stmt->execute()) {
        echo "<script>alert('Record updated successfully.'); window.location.href = 'contact_us_report.php';</script>";
    } else {
        echo "<script>alert('Failed to update record: " . $stmt->error . "'); window.location.href = 'contact_us_report.php';</script>";
    }

    $stmt->close();
}

$conn->close();
?>
