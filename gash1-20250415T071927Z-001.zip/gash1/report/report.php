<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kiziguro";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_query = "DELETE FROM student_registration WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        echo "<script>alert('Record deleted successfully.');</script>";
    } else {
        echo "<script>alert('Failed to delete record: " . $stmt->error . "');</script>";
    }
    $stmt->close();
}

// Fetch all records
$query = "SELECT * FROM student_registration ORDER BY created_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Database Report of GS Kiziguro TSS - Insights and details about the school's database systems and operations.">
    <meta name="keywords" content="GS Kiziguro TSS, Database Report, School Data, Education Management">
    <meta name="author" content="Gashema Francis">
    <meta name="robots" content="index, follow">
    <title>Database Report | GS Kiziguro TSS</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .actions button {
            margin-right: 5px;
            padding: 5px 10px;
        }
         /* General Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    color: #333;
    background-color: #f9f9f9;
}

/* Header */
header {
    background-color: #188fa7;
    color: #fff;
    padding: 20px 10px;
    text-align: center;
}

header .logo {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

header .logo img {
    height: 50px;
    border-radius: 50%;
}

header nav ul {
    list-style: none;
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-top: 10px;
}

header nav ul li a {
    color: #fff;
    text-decoration: none;
    padding: 5px 10px;
    border-radius: 5px;
}

header nav ul li a:hover,
header nav ul li a.active {
    background-color: #2394ab;
}

/* Main */
main {
    padding: 20px;
}

main .report-overview {
    text-align: center;
    margin-bottom: 20px;
}

main .report-overview h2 {
    color: #188fa7;
    font-size: 2em;
    margin-bottom: 10px;
}

main .report-overview p {
    font-size: 1.2em;
    color: #666;
}

/* Report Details */
.report-details {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
}

.report-card {
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    width: 300px;
    text-align: center;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.report-card h3 {
    color: #188fa7;
    margin-bottom: 10px;
}

.report-card p {
    color: #555;
}

/* Footer */
footer {
    background-color: #188fa7;
    color: #fff;
    text-align: center;
    padding: 10px;
    margin-top: 20px;
}

/* Responsive Design */
@media (max-width: 768px) {
    header nav ul {
        flex-direction: column;
    }

    .report-details {
        flex-direction: column;
        align-items: center;
    }
}
#contact-report-section table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

#contact-report-section th, #contact-report-section td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

#contact-report-section th {
    background-color: #f2f2f2;
    font-weight: bold;
}

#contact-report-section tr:nth-child(even) {
    background-color: #f9f9f9;
}

#contact-report-section tr:hover {
    background-color: #f1f1f1;
}

button {
    background-color: #f44336; /* Red */
    color: white;
    border: none;
    padding: 5px 10px;
    cursor: pointer;
}

button:hover {
    background-color: #d32f2f;
}

    </style>

</head>
<body>
    <header>
        <div class="logo">
            <img src="../update/image/WhatsApp Image 2024-11-17 at 11.55.32_3b0a3dee.jpg" alt="GS Kiziguro TSS Logo">
            <h1>GS Kiziguro TSS</h1>
        </div>
        <nav>
            <ul>
                <li><a href="../try/dist/index.html">Home</a></li>

            </ul>
        </nav>
    </header>

    <h1 style="text-align: center; color:#188fa7"> <u>Students Request Tobe Registered</u></h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Student Name</th>
                <th>Family Name</th>
                <th>Gender</th>
                <th>Family ID</th>
                <th>Phone</th>
                <th>Level</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) : ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['student_name']) ?></td>
                    <td><?= htmlspecialchars($row['family_name']) ?></td>
                    <td><?= htmlspecialchars($row['student_gender']) ?></td>
                    <td><?= htmlspecialchars($row['family_id']) ?></td>
                    <td><?= htmlspecialchars($row['family_phone']) ?></td>
                    <td><?= htmlspecialchars($row['student_level']) ?></td>
                    <td class="actions">
                        <a href="report.php?delete_id=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to delete this record?')">
                            <button style="color: red;">Delete</button>
                        </a>
                        <button onclick="editRecord(<?= htmlspecialchars(json_encode($row)) ?>)">Edit</button>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Update Form Modal -->
    <div id="updateForm" style="display:none; position:fixed; top:20%; left:30%; background:#fff; border:1px solid #ccc; padding:20px;">
        <h2>Update Record</h2>
        <form id="updateFormElement" method="POST" action="update_student.php">
            <input type="hidden" name="id" id="edit_id">
            <label>Student Name:</label>
            <input type="text" name="student_name" id="edit_student_name" required>
            <br>
            <label>Family Name:</label>
            <input type="text" name="family_name" id="edit_family_name" required>
            <br>
            <label>Gender:</label>
            <input type="text" name="student_gender" id="edit_student_gender" required>
            <br>
            <label>Family ID:</label>
            <input type="number" name="family_id" id="edit_family_id" required>
            <br>
            <label>Phone:</label>
            <input type="text" name="family_phone" id="edit_family_phone" required>
            <br>
            <label>Level:</label>
            <input type="text" name="student_level" id="edit_student_level" required>
            <br><br>
            <button type="submit">Update</button>
            <button type="button" onclick="document.getElementById('updateForm').style.display='none'">Cancel</button>
        </form>
    </div>

    <script>
        // Function to populate and show update form
        function editRecord(record) {
            document.getElementById('edit_id').value = record.id;
            document.getElementById('edit_student_name').value = record.student_name;
            document.getElementById('edit_family_name').value = record.family_name;
            document.getElementById('edit_student_gender').value = record.student_gender;
            document.getElementById('edit_family_id').value = record.family_id;
            document.getElementById('edit_family_phone').value = record.family_phone;
            document.getElementById('edit_student_level').value = record.student_level;
            document.getElementById('updateForm').style.display = 'block';
        }
    </script>
    <section>

    <main>
        <section class="report-overview">
        <?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'kiziguro');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle deletion if 'delete_id' is set in the GET request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_sql = "DELETE FROM contact_us WHERE id = $delete_id";
    if ($conn->query($delete_sql) === TRUE) {
        echo "<p style='color: green;'>Record with ID $delete_id deleted successfully.</p>";
    } else {
        echo "<p style='color: red;'>Error deleting record: " . $conn->error . "</p>";
    }
}

// Fetch data from the contact_us table
$sql = "SELECT * FROM contact_us";
$result = $conn->query($sql);
?>

<!-- Reporting Section -->
<section id="contact-report-section">
    <h2>Contact Us Report</h2>

    <?php if ($result->num_rows > 0): ?>
        <table border="1" cellpadding="10" cellspacing="0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Description</th>
                    <th>Submitted At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['contact']); ?></td>
                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                        <td>
                            <?php
                            echo isset($row['submission_time']) ? htmlspecialchars($row['submission_time']) : "N/A";
                            ?>
                        </td>
                        <td>
                            <!-- Delete Button -->
                            <form method="GET" style="display: inline;">
                                <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" onclick="return confirm('Are you sure you want to delete this record?');">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No contact messages found.</p>
    <?php endif; ?>

    <?php
    // Close the connection
    $conn->close();
    ?>
</section>



        </section>

        <section id="contact-report-section">



    </section>
</body>
</html>


