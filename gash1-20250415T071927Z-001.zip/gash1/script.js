// JavaScript for handling form submission
document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the form from submitting in the traditional way
  
    // Get form values
    const name = document.getElementById("contact_name").value;
    const contact = document.getElementById("contact_number").value;
    const description = document.getElementById("contact_description").value;
  
    // Display confirmation message
    const confirmationMessage = `
      Thank you for contacting us!<br>
      Your Name: ${name}<br>
      Your Email or Phone Number: ${contact}<br>
      Your Description: ${description}
    `;
  
    document.getElementById("confirmationMessage").innerHTML = confirmationMessage;
  });



// about us section 
document.getElementById('principles-btn').addEventListener('click', function() {
  var moreContent = document.getElementById('principles-more');
  if (moreContent.style.display === "none") {
    moreContent.style.display = "block";
  } else {
    moreContent.style.display = "none";
  }
});

document.getElementById('mission-btn').addEventListener('click', function() {
  var moreContent = document.getElementById('mission-more');
  if (moreContent.style.display === "none") {
    moreContent.style.display = "block";
  } else {
    moreContent.style.display = "none";
  }
});

document.getElementById('values-btn').addEventListener('click', function() {
  var moreContent = document.getElementById('values-more');
  if (moreContent.style.display === "none") {
    moreContent.style.display = "block";
  } else {
    moreContent.style.display = "none";
  }
});


// Mobile Dropdown Menu Toggle

function toggleMenu() {
  const navLinks = document.getElementById('navLinks');
  navLinks.classList.toggle('active');
}

//

// show learn more button
document.getElementById('principles-btn').addEventListener('click', function() {
  var moreContent = document.getElementById('principles-more');
  if (moreContent.style.display === "none") {
    moreContent.style.display = "block";
  } else {
    moreContent.style.display = "none";
  }
});

document.getElementById('mission-btn').addEventListener('click', function() {
  var moreContent = document.getElementById('mission-more');
  if (moreContent.style.display === "none") {
    moreContent.style.display = "block";
  } else {
    moreContent.style.display = "none";
  }
});

// Particle generation  hero
const particleContainer = document.querySelector('.hero-particles');
for (let i = 0; i < 500; i++) {
    const particle = document.createElement('div');
    particle.classList.add('particle');
    particle.style.left = `${Math.random() * 100}%`;
    particle.style.animationDelay = `${Math.random() * 5}s`;
    particle.style.animationDuration = `${Math.random() *  + 3}s`;
    particleContainer.appendChild(particle);
}
