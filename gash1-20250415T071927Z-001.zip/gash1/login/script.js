// Login form validation
document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent form from submitting

    // Valid credentials
    const validUsers = [
        { username: "Gskiziguro@dot123", password: "dot@2024-2025" },
        { username: "globally@gskiziguro", password: "kzgr2024-2025" }
    ];

    // Get user input
    const usernameInput = document.getElementById('username').value;
    const passwordInput = document.getElementById('password').value;

    // Check if credentials match
    const user = validUsers.find(user => user.username === usernameInput && user.password === passwordInput);

    // Display result
    const errorMessage = document.getElementById('error-message');
    if (user) {
        errorMessage.style.color = "green";
        errorMessage.textContent = "Login successful!";
        setTimeout(() => {
            window.location.href = "../report/report.php"; // Redirect to dashboard (replace with your desired URL)
        }, 1000);
    } else {
        errorMessage.style.color = "red";
        errorMessage.textContent = "Invalid username or password!";
    }
});
