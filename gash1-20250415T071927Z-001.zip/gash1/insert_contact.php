<?php
// Set the header to return JSON
header('Content-Type: application/json');

// Database connection
$conn = new mysqli('localhost', 'root', '', 'kiziguro');

// Check connection
if ($conn->connect_error) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed: ' . $conn->connect_error
    ]);
    exit();
}

// Validate and sanitize input
$name = isset($_POST['contact_name']) ? trim($_POST['contact_name']) : '';
$contact = isset($_POST['contact_number']) ? trim($_POST['contact_number']) : '';
$description = isset($_POST['contact_description']) ? trim($_POST['contact_description']) : '';

if (empty($name) || empty($contact) || empty($description)) {
    echo json_encode([
        'success' => false,
        'message' => 'All fields are required.'
    ]);
    exit();
}

// Prepare and execute the insert query
$stmt = $conn->prepare("INSERT INTO contact_us (name, contact, description) VALUES (?, ?, ?)");
$stmt->bind_param('sss', $name, $contact, $description);

if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Your message has been submitted successfully.'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $stmt->error
    ]);
}

// Close connections
$stmt->close();
$conn->close();
?>
